

<?php $__env->startSection('title', 'Baixar Documentos'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Baixar Arquivos</h1>

    <ol class="breadcrumb">
        <li><a href="">Home&nbsp;|&nbsp;</a><li>
        <li><a href="">Users&nbsp;|&nbsp;</a><li >        
        <li><a href="">Download</a><li >        
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Baixar Documentos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  

<div class="container">
   <!--tabela resultado-->
   <?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>

   <!--Implementar pesquisar automaticamente -->
  
   <?php if(!empty($file)): ?> 
        <div class="box">
            <div class="box-header">                
            <div class="box-body">
                <table class="table table-bordered table-hover">
                    <thead class="thead thead-dark">
                        <tr>
                            
                            <th>Nome</th>

                            <th>status</th>
                            <th>Conteudo</th>
                            <th>Industria</th>
                            <th>Validade</th>
                            <th>Versão</th>
                            <th>Ação</th>
                            
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $file; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($Item->name); ?></td>
                                <td><?php echo e($Item->estado); ?></td>
                                <td><?php echo e($Item->conteudo); ?></td>
                                <td><?php echo e($Item->industria); ?></td>
                                <td><?php echo e($Item->Validadedoc); ?></td>
                                <td><?php echo e($Item->versao); ?></td>                                
                                <td><button class="btn btn-primary">Editar</button>
                                    <button class="btn btn-secondary">Visualizar</button> 
                                    <button class="btn btn-danger">Excluir</button>   
                                                                    
                                </td>
                            </tr>                             
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>                         
                    </tbody>
                </table>                
            </div>  
        </div>
<!-- essa div precisa ser  vista ainda-->
 </div>
 <?php endif; ?> 



<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\www\Projeto_Site\resources\views/users/downloads/down.blade.php ENDPATH**/ ?>