

<?php $__env->startSection('title', 'AdminLTE'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Docs - Upload</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <p class="mb-0">UpLoad de Arquivos</p>
                </div>
            </div>
        </div>
    </div>
    <form method="post" action="<?php echo e(route('FilesController.uploads')); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <input type='text' class="form-control" id="nome" name="nome"  />
        <input type='text' class="form-control" id="industria" name="industria"  />
        <input type='text' class="form-control" id="Validadedoc" name="Validadedoc"  />
        <input type='text' class="form-control"  id="conteudo" name="conteudo" />
        <input type='data'  class="form-control" id="industria" name="Validadedoc" />
        <select type='text' class="form-control"  id="estado" name="Validadedoc">
        <?php $__currentLoopData = ["ativo" => "Ativo", "inativo" => "Inativo", "cancelado" => "Cancelado"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $statusLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
            <option value="<?php echo e($status); ?>" <?php echo e(old('estado', $customer_event->status) == $status ? "selected" : ""); ?>><?php echo e($statusLabel); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <input type='text' class="form-control" id="versao" name="versao"  />
        
        <input type='file' class="form-control" id="primaryImage" name="primaryImage" accept="image/*" />


        <button type="submit" class="btn btn-block btn-success">
            <i class="fa fa-save"></i> Salvar
        </button>
    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\www\Projeto_Site\resources\views/docs/upload.blade.php ENDPATH**/ ?>